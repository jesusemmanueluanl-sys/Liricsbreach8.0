package com.lyricsbridge.app

import android.app.Activity
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import java.net.URL
import kotlin.concurrent.thread

class MainActivity : Activity() {
    private lateinit var status: TextView
    private lateinit var output: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val pad = (16 * resources.displayMetrics.density).toInt()
        val col = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(pad, pad, pad, pad) }

        status = TextView(this).apply { textSize = 16f }
        output = TextView(this).apply { textSize = 13f; setTextIsSelectable(true) }

        fun button(label: String, action: () -> Unit) = Button(this).apply {
            text = label
            setOnClickListener { action() }
        }

        col.addView(status)
        col.addView(button("1. Dar acceso a notificaciones") {
            startActivity(Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS))
        })
        col.addView(button("2. Quitar optimización de batería") {
            startActivity(
                Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS, Uri.parse("package:$packageName"))
            )
        })
        col.addView(button("3. Probar (ver canción actual)") { probe() })
        col.addView(output)

        setContentView(ScrollView(this).apply { addView(col) })
    }

    override fun onResume() {
        super.onResume()
        val enabled = Settings.Secure.getString(contentResolver, "enabled_notification_listeners")
            ?.contains(packageName) == true
        status.text = if (enabled) "Acceso a notificaciones: ACTIVO\nServidor local: 127.0.0.1:${Bridge.DEFAULT_PORT}"
        else "Acceso a notificaciones: FALTA ACTIVAR"
    }

    private fun probe() {
        output.text = "Consultando…"
        thread {
            val text = try {
                URL("http://127.0.0.1:${Bridge.DEFAULT_PORT}/now").readText()
            } catch (e: Exception) {
                "Sin respuesta: ${e.message}"
            }
            runOnUiThread { output.text = text }
        }
    }
}
