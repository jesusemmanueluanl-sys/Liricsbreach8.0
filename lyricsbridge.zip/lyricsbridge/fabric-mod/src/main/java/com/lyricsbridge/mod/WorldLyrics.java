package com.lyricsbridge.mod;

import com.mojang.blaze3d.vertex.PoseStack;
import net.fabricmc.fabric.api.client.rendering.v1.level.LevelRenderContext;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.Font;
import net.minecraft.client.renderer.state.level.CameraRenderState;
import net.minecraft.network.chat.Component;
import net.minecraft.util.FormattedCharSequence;
import net.minecraft.world.phys.Vec3;
import org.joml.Matrix4f;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;

/**
 * Letra flotando por todos lados, UNA palabra a la vez.
 *
 * Cada palabra de la linea actual aparece en un punto distinto de una esfera
 * alrededor del jugador (adelante, atras, arriba, abajo, a los lados), flota
 * un rato y se desvanece. Siempre mira hacia la camara.
 *
 * Propiedades opcionales (-D en los argumentos de la JVM):
 *   lyricsbridge.scale    tamano del texto           (def. 0.05)
 *   lyricsbridge.distance distancia minima en bloques (def. 2.5)
 *   lyricsbridge.wordms   ms base por palabra         (def. 380)
 *   lyricsbridge.life     segundos que vive cada palabra (def. 3.0)
 *   lyricsbridge.orbit    giro alrededor de ti en rad/s   (def. 0.25, 0 = quieto)
 */
public final class WorldLyrics {
    private WorldLyrics() {}

    private static final int FULL_BRIGHT = 0xF000F0;

    private static final float SCALE = (float) prop("lyricsbridge.scale", 0.05);
    private static final double DIST = prop("lyricsbridge.distance", 2.5);
    private static final double WORD_MS = prop("lyricsbridge.wordms", 380);
    private static final double LIFE_S = prop("lyricsbridge.life", 3.0);
    private static final double ORBIT = prop("lyricsbridge.orbit", 0.25); // rad/s, 0 = sin giro
    private static final int MAX_ALIVE = 28;

    private static final class Floater {
        String text;
        double ox, oy, oz;     // desplazamiento respecto a la camara
        double vx, vy, vz;     // deriva lenta
        float size;
        long bornNs;
        double phase;
    }

    private static final List<Floater> alive = new ArrayList<>();
    private static final Random RNG = new Random();

    private static String curLine = "";
    private static String[] words = new String[0];
    private static long[] dueNs = new long[0];
    private static int spawned = 0;

    public static void reset() {
        alive.clear();
        curLine = "";
        words = new String[0];
        dueNs = new long[0];
        spawned = 0;
    }

    private static double prop(String key, double def) {
        try {
            return Double.parseDouble(System.getProperty(key, Double.toString(def)));
        } catch (NumberFormatException e) {
            return def;
        }
    }

    /** Se llama cada frame desde LyricsBridgeClient. prev/next ya no se usan. */
    public static void render(LevelRenderContext ctx, String prev, String line, String next) {
        long now = System.nanoTime();
        String l = line == null ? "" : line.trim();

        if (!l.equals(curLine)) {
            curLine = l;
            if (l.isEmpty()) {
                words = new String[0];
                dueNs = new long[0];
            } else {
                words = l.split("\\s+");
                dueNs = new long[words.length];
                long t = now;
                for (int i = 0; i < words.length; i++) {
                    dueNs[i] = t;
                    double ms = WORD_MS + 40.0 * words[i].length();
                    t += (long) (Math.min(ms, 1200.0) * 1_000_000.0);
                }
            }
            spawned = 0;
        }

        Minecraft mc = Minecraft.getInstance();
        Font font = mc.font;
        if (font == null) return;

        CameraRenderState cam = ctx.levelState().cameraRenderState;
        Vec3 cp = cam.pos;

        // Soltar las palabras que ya les toca
        while (spawned < words.length && dueNs[spawned] <= now) {
            spawn(words[spawned], now);
            spawned++;
        }

        if (alive.isEmpty()) return;

        long lifeNs = (long) (LIFE_S * 1_000_000_000.0);
        Matrix4f billboard = new Matrix4f().rotation(cam.orientation);

        for (int i = alive.size() - 1; i >= 0; i--) {
            Floater f = alive.get(i);
            long age = now - f.bornNs;
            if (age >= lifeNs) {
                alive.remove(i);
                continue;
            }
            double s = age / 1_000_000_000.0;
            double t = age / (double) lifeNs; // 0..1

            // Opacidad: entra rapido, sale suave
            double a;
            if (s < 0.15) a = s / 0.15;
            else if (t > 0.7) a = (1.0 - t) / 0.3;
            else a = 1.0;
            int alpha = (int) Math.max(6, Math.min(255, a * 255));

            // La palabra mas reciente va en dorado, las demas en blanco
            boolean newest = (i == alive.size() - 1);
            int rgb = newest ? 0xFFD54A : 0xFFFFFF;
            int argb = (alpha << 24) | rgb;

            // Pop de tamano al aparecer
            double pop = s < 0.2 ? 0.6 + 2.0 * s : 1.0;
            float sc = (float) (SCALE * f.size * pop);

            double bob = Math.sin(s * 1.6 + f.phase) * 0.12;
            // Giro lento alrededor del jugador (como "orbit" del video)
            double ang = ORBIT * s;
            double ca = Math.cos(ang), sa = Math.sin(ang);
            double rx = f.ox * ca - f.oz * sa;
            double rz = f.ox * sa + f.oz * ca;
            double x = cp.x + rx + f.vx * s;
            double y = cp.y + f.oy + f.vy * s + bob;
            double z = cp.z + rz + f.vz * s;

            PoseStack pose = new PoseStack();
            pose.translate(x - cp.x, y - cp.y, z - cp.z);
            pose.mulPose(billboard);
            pose.scale(sc, -sc, sc);

            FormattedCharSequence seq = Component.literal(f.text).getVisualOrderText();
            float w = font.width(seq);
            ctx.submitNodeCollector().submitText(
                    pose, -w / 2f, 0f, seq, true,
                    Font.DisplayMode.NORMAL, FULL_BRIGHT, argb, 0, 0);
        }
    }

    private static void spawn(String word, long now) {
        // Punto aleatorio en una esfera completa alrededor del jugador
        double yaw = RNG.nextDouble() * Math.PI * 2.0;
        double pitch = Math.toRadians(-50 + RNG.nextDouble() * 110); // un poco mas arriba que abajo
        double r = DIST + RNG.nextDouble() * 3.5;

        Floater f = new Floater();
        f.text = word;
        f.ox = Math.cos(pitch) * Math.cos(yaw) * r;
        f.oz = Math.cos(pitch) * Math.sin(yaw) * r;
        f.oy = Math.sin(pitch) * r;
        f.vx = (RNG.nextDouble() - 0.5) * 0.3;
        f.vy = 0.15 + RNG.nextDouble() * 0.2;
        f.vz = (RNG.nextDouble() - 0.5) * 0.3;
        f.size = (float) (0.85 + RNG.nextDouble() * 0.6);
        f.phase = RNG.nextDouble() * Math.PI * 2.0;
        f.bornNs = now;

        alive.add(f);
        while (alive.size() > MAX_ALIVE) alive.remove(0);
    }
}
